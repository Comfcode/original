COMFORTLINE.BY — РЕДАКЦИОННЫЙ ПАКЕТ / PUBLICATION PACKAGE
Актуальность исследования / Research verified: 16 октября / October 2026

1. comfortline_interactive_border_guide_2026.html
   Готовая автономная адаптивная веб-страница с полным текстом на русском и английском языках,
   переключателем RU/EN, выбором гражданства из 249 ISO-стран/территорий плюс два
   специальных статуса, формой по 15 характеристикам поездки и проверкой основных санкций.
   Все стили и JavaScript встроены. Никакие пользовательские данные никуда не отправляются.

2. comfortline_border_research_ru_en_2026.md
   Полный редакционный текст RU + EN с 26 ссылками на источники и примерами.
   Можно перенести в CMS/блог Comfortline.by как два локализованных материала.

ВНЕДРЕНИЕ:
- Самый быстрый вариант: разместить HTML как самостоятельную страницу/статический файл
  на сайте и дать на неё ссылку из навигации Comfortline.by.
- Для вставки в уже существующий шаблон перенесите содержимое .article,
  CSS и JS в архитектуру сайта; устраните конфликты global selectors в CSS.
- CMS может отфильтровать JavaScript, если просто вставить HTML в визуальный редактор.
  В таком случае подключать JS как отдельный доверенный скрипт в коде сайта.
- Перед публикацией необходимо провести редакционно-юридическую проверку
  по действующей на дату публикации редакции законодательства, включая CN,
  санкционные приложения и режимы границ. Дата 16.10.2026 — дата исследования,
  а не обещание неизменности правил.
- Интерактивная анкета — screening, не юридическое заключение и не сервис
  фактической проверки в онлайн-базах погранслужб.

EN:
- HTML is a complete standalone, bilingual, responsive article and in-browser checker.
- Markdown is the full editable editorial source with 26 legal/official references.
- Host the HTML as a standalone page, or integrate its styles/JS into your website template.
- The checker does not transmit data and cannot guarantee border access or customs approval.
- Revalidate legal rules and operating crossings before publication and update regularly.
