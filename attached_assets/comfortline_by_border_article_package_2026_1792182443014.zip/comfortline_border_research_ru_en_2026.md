<!-- Comfortline.by bilingual editorial draft | Reviewed 2026-10-16 -->

# Как въехать в Беларусь из Польши, Литвы и Латвии на автомобиле в 2026 году

**Юридико-практический обзор Comfortline.by • Дата проверки: 16 октября 2026 года • Редакция 1.0**

**Главное:** законность поездки зависит не от одного паспорта или номерного знака. Проверяются независимо (1) право человека въехать в Беларусь и затем вернуться в ЕС, (2) действующий пункт пропуска, (3) санкционный режим ЕС для экспорта автомобиля из ЕС в Беларусь, (4) правила обратного въезда белорусских автомобилей в ЕС, (5) таможенный режим временного/постоянного ввоза в ЕАЭС. Дополнительно важны личное или коммерческое использование, собственник, страховка и регистрация очереди. **Открытый переход ≠ разрешённый автомобиль ≠ гарантированный въезд пассажира.**

> **Важно о безопасности и праве:** это исследовательский информационный материал, а не заключение юриста или разрешение таможни. Проверка по анкете — предварительный скрининг, а не официальный правовой статус. Пункты пропуска могут закрыться без предупреждения. Некоторые государственные ведомства рекомендуют не совершать поездки в Беларусь; отдельно проверьте рекомендации МИД своей страны. Не передавайте паспортные данные и VIN в публичные формы без необходимости.

## 1. Где можно пересечь границу на легковом автомобиле

| Направление | Международные переходы для легковых авто, по последним подтверждениям | Особенности |
|---|---|---|
| Польша → Беларусь | **Terespol — Brest**, **Bobrowniki — Berestovitsa**, **Kuźnica — Bruzgi** | Bobrowniki: легковые и автобусы; Kuźnica: легковые, **без автобусов**. Połowce и Sławatycze закрыты; Koroszczyn/Kukuryki — грузовое направление. [S8][S15] |
| Литва → Беларусь | **Medininkai — Kamenny Log**, **Šalčininkai — Benyakoni** | Оба перехода восстановили работу в ноябре 2025 г.; Kotlovka/Lavoriškės и Privalka/Raigardas не считайте доступной альтернативой без нового официального подтверждения. [S9][S21] |
| Латвия → Беларусь | **Pāternieki — Grigorovshchina** | Регистрация ТС в электронной очереди обязательна, в том числе для легковых машин; на Pāternieki были технические перерывы летом 2026 г., работу необходимо проверить перед выездом. Silene нельзя считать обычной доступной альтернативой. [S10][S25] |

Правила одного государства нельзя переносить на другое. Например, порядок допуска машин с белорусскими номерами в Польше отличается от литовского и латвийского. Прохождение очереди не заменяет ни визы, ни таможенную проверку.

## 2. Санкции ЕС: объём двигателя, клиренс, цена и год выпуска

Базовый акт — **Регламент Совета (ЕС) № 765/2006**, в действующей консолидированной редакции с изменениями 2024–2026 гг. Для автомобилей особенно важны **статья 1bb и Приложение XVIII** (запрещённые для вывоза/передачи в Беларусь определённые категории товаров) и **статья 1ga и Приложение XXV** (предметы роскоши, включая транспортные средства соответствующей стоимости). Статья 1ra и связанные приложения относятся к ввозу некоторых товаров/автомобилей из Беларуси в ЕС. [S1][S3][S4]

### 2.1. Таблица автомобильных признаков по Приложению XVIII

| Тип легкового автомобиля (CN 8703) | Критерий по двигателю | Критерий дорожного просвета | Предварительный вывод |
|---|---|---|---|
| Бензиновый (только ДВС) | **Более 1 900 см³**, не 1 900 ровно | **Не менее 165 мм** | Совпадение обоих критериев — санкционный риск/запрет по ст. 1bb |
| Дизельный (только ДВС) | **Более 1 900 см³** | **Не менее 165 мм** | Аналогично |
| Гибрид без внешней зарядки (HEV) | Лимит 1 900 см³ для этих CN-позиций **не указан** | **Не менее 165 мм** | Подпадает под соответствующую позицию |
| Подзаряжаемый гибрид (PHEV) | Объём не является критерием этой позиции | **Не менее 165 мм** | Подпадает под соответствующую позицию |
| Электромобиль (BEV) | Объём ДВС отсутствует | **Не менее 165 мм** | Подпадает под соответствующую позицию |
| Другой привод / специальный CN | Требуется точный код | Зависит от позиции | Без индивидуальной классификации автоматический вывод невозможен |

**Пограничные значения имеют значение:** 1 900 см³ ровно не является «более 1 900»; 165 мм ровно является «не менее 165». Клиренс оценивается по определению приложения (вертикальное расстояние от нижней части шасси до дороги), а не по произвольной рекламной характеристике. Обозначение **ex** означает, что запрет относится лишь к товарам, отвечающим описанию, а не ко всему коду CN. Исключения и другие позиции (например, специальные транспортные средства) нуждаются в анализе документации. [S2]

### 2.2. Имеет ли значение год автомобиля?

**Сам по себе год выпуска не является универсальным разрешением или запретом по указанной санкционной автомобильной таблице.** Даже старый автомобиль с объёмом 2,2 л и клиренсом 180 мм может попадать под критерии; новый седан 1,5 л/140 мм может не попадать под эти конкретные позиции, но всё равно требовать иных проверок. Год и возраст важны прежде всего для **постоянного таможенного ввоза** в ЕАЭС: в тарифах различаются автомобили до 3 лет, старше 3 до 5 лет и старше 5 лет, учитываются стоимость и рабочий объём. [S2][S13][S23]

### 2.3. Цена свыше 50 000 евро: почему это НЕ универсальный запрет для седанов и SUV

**Важное изменение законодательства:** Приложение XXV к Регламенту № 765/2006 содержит ограничения на отдельные категории предметов роскоши, в том числе товары транспортной сферы, стоимостью **свыше 50 000 €**. Однако **Регламент (ЕС) 2025/2041 от 23.10.2025 заменил таблицу (9) Приложения XXV**: в действующем перечне указаны, например, CN **8702** (автобусы), **8706** (шасси), **8707** (кузова), **8708** (части и принадлежности) и другие позиции, **но не обычный легковой автомобиль CN 8703 как таковой**. Поэтому говорить «любой седан/внедорожник дороже 50 000 € запрещён лишь по цене» некорректно.

**Практический вывод:** для обычного легкового CN 8703 остаётся прежде всего тест Приложения XVIII по типу двигателя/объёму/клиренсу и иные применимые запреты. Цена важна для установления товарной категории, таможенной стоимости и иных режимов, но **не должна автоматически создавать красный санкционный статус только из-за превышения 50 000 €**. Для микроавтобусов, спецтехники, автокомпонентов и неоднозначного CN необходимо самостоятельно сверить конкретную позицию Приложения XXV. [S1][S26]

### 2.4. Даже если автомобиль на номерах ЕС и едет «только на выходные»?

Да: по официальному разъяснению **таможни Литвы от 15.09.2026**, пересечение автомобилем границы таможенной территории ЕС с целью временного выезда в третью страну может квалифицироваться как экспорт; в обычных условиях отдельная электронная экспортная декларация не всегда требуется, но **отсутствие декларации не отменяет санкционных запретов**. При определении режима анализируют CN, тип двигателя, объём и клиренс, а не только государство регистрации. Нельзя считать туристическую поездку автоматическим исключением. [S2]

## 3. Паспорта и гражданство: кому доступен белорусский безвиз

Беларусь продлила временный безвиз до **31 декабря 2026 года включительно** для граждан **38 европейских государств**. Он охватывает все **27 стран ЕС**: Австрию, Бельгию, Болгарию, Венгрию, Германию, Грецию, Данию, Ирландию, Испанию, Италию, Кипр, Латвию, Литву, Люксембург, Мальту, Нидерланды, Польшу, Португалию, Румынию, Словакию, Словению, Финляндию, Францию, Хорватию, Чехию, Швецию и Эстонию. Также включены **11 не входящих в ЕС стран**: Андорра, Босния и Герцеговина, Ватикан, Великобритания, Исландия, Лихтенштейн, Монако, Норвегия, Северная Македония, Сан-Марино и Швейцария. Предусмотрены специальные категории неграждан Латвии и лиц без гражданства, постоянно проживающих в Эстонии; документы и статус надо проверять отдельно. [S11][S12]

- **Польша, Литва, Латвия и неграждане Латвии**: до **90 суток за один визит** при соблюдении общего лимита **90 суток в календарном году**.
- **Остальные 35 государств**: до **30 суток за один визит**, максимум **90 суток в календарном году**.
- **Граждане Беларуси** въезжают в свою страну по белорусским документам; к ним не применяют иностранный туристический безвиз.
- **Иные гражданства мира**: могут существовать двусторонние соглашения или иные режимы, но само наличие ВНЖ/визы ЕС не создаёт права на белорусский безвиз. Индивидуально проверьте режим по гражданству и типу паспорта в белорусских официальных источниках.

Этот наземный безвиз применяется к международным автомобильным и железнодорожным пунктам, **не даёт автоматически права на безвизовый маршрут через Россию** и обычно не распространяется на служебные и специальные паспорта. Для визита нужны действительный проездной документ, применимые медицинская страховка и другие документы; перед выездом убедитесь в актуальности правил. [S11][S22]

**Важно при возвращении:** право гражданина ЕС вернуться в ЕС отличается от статуса гражданина третьей страны. Для граждан Беларуси наличие белорусского паспорта/права на въезд в Беларусь **не подтверждает право обратного въезда в Польшу, Литву или Латвию**. Нужны соответствующие визовые/миграционные основания и соблюдение шенгенских правил (в общем случае краткое пребывание до 90 дней в любые 180 дней). Визы Ирландии и Кипра не равны шенгенской визе. Отдельно учитывайте национальные ограничения и проверки безопасности. [S17][S18]

## 4. Регистрационные номера: BY, PL, LT, LV и другие

**Номера PL/LT/LV/DE или иные ЕС.** Въезд в Беларусь на частной машине не становится автоматически законным: проверяют запреты **на вывоз автомобиля из ЕС**, страхование, владельца и таможенный статус после въезда. На обратном пути проверяются право лица въехать в ЕС и соблюдение правил ввоза автомобиля. [S2]

**Номера BY.** Главный риск часто возникает при **возвращении из Беларуси в ЕС**, поскольку применяется статья 1ra Регламента № 765/2006 и национальный порядок исключений:

- **Польша:** по опубликованному разъяснению KAS возможен допуск определённых машин, принадлежащих физическим лицам и используемых лично, при наличии **собственника в автомобиле** и соблюдении прочих условий. Это не общее разрешение для фирменного автомобиля, автомобиля на продажу или коммерческой перевозки. [S5]
- **Литва:** опубликованные исключения уже. Среди них личный автомобиль гражданина Беларуси, который **сам управляет автомобилем**, имеет действительную **литовскую визу или литовский ВНЖ** и не использует автомобиль коммерчески; либо определённые граждане ЕС, проживающие в Беларуси. Не следует автоматически считать шенгенскую визу другого государства достаточной для литовского исключения. [S6]
- **Латвия:** таможенная служба объявила запрет на въезд обычных легковых машин с белорусской регистрацией, с узкими исключениями, например для дипломатического транспорта. **Не планируйте возвращение через Pāternieki на BY-номерах, пока не получите официального подтверждения применимого исключения.** [S7]

**Номера иных стран (Великобритания, Швейцария, Норвегия, США, Украина и др.)**: гражданство водителя не равно стране регистрации, а регистрация не исчерпывает критерии таможенного статуса и экспортного контроля. Для движения через ЕС и Беларусь нужна отдельная проверка по маршруту и обстоятельствам. **Номера ЕАЭС (BY/RU/KZ/AM/KG)** не следует объединять с номерами ЕС.

## 5. Таможня Беларуси: временный въезд и растаможка — не одно и то же

Если иностранное физическое лицо временно ввозит в ЕАЭС личный автомобиль с регистрацией вне ЕАЭС, **статья 264 Таможенного кодекса ЕАЭС** предусматривает временный ввоз **на срок не более одного года** при соблюдении условий. Для физического лица государства ЕАЭС, ввозящего иностранный автомобиль, в общем случае требуется **обеспечение уплаты таможенных пошлин и налогов**; для второго и последующего автомобиля обеспечение возможно и для иностранного лица. Правовой статус определяется таможенным правом и фактическим постоянным проживанием, а не просто выбранным в анкете гражданством. [S13]

Если автомобиль ввозят для постоянной регистрации/продажи, проверяют **таможенную стоимость, возраст, объём, тип двигателя, пошлины, налоги, утилизационный сбор**, а также актуальные специальные режимы (например, применимые к определённым электромобилям). **Не используйте туристический режим временного ввоза для обхода постоянного оформления.** [S23]

## 6. Документы, страховка и процедура

Перед поездкой подготовьте: паспорт и законное основание въезда/выезда; водительское удостоверение, свидетельство о регистрации, подтверждение права пользования автомобилем (особенно не собственник, аренда, лизинг, корпоративная машина); отдельную страховку гражданской ответственности, действующую в Беларуси, и страховку для обратного въезда в ЕС; медицинскую страховку, если требуется; документы на автомобиль с подтверждением двигателя/клиренса/стоимости, таможенной классификации и цели поездки. **«Зелёные карты» ЕС и Беларуси перестали автоматически взаимно признаваться с 2023 года**: заранее уточните пограничное страхование. [S16]

Для выезда из Латвии через Pāternieki бронируйте время на **lvborder.lv**; для остальных направлений заранее проверяйте официальные электронные очереди и текущие ограничения. Пограничные ведомства могут потребовать дополнительные документы и осмотр. [S10][S21]

## 7. Практические примеры (упрощённые, не юридическое разрешение)

1. **Гражданка Литвы, литовские номера, бензин 1 798 см³, клиренс 150 мм, цена 14 000 €, частная поездка:** указанные критерии Приложения XVIII для бензинового автомобиля не совпадают, но остаются иные санкционные проверки, граница и страховка. Белорусский наземный безвиз для гражданки Литвы потенциально применим до 90 суток за визит.
2. **Гражданин Польши, польские номера, дизель 1 968 см³, 180 мм, авто 2015 года, поездка в Беларусь:** возраст 2015 г. не спасает; пересечение параметров **> 1 900 см³ + ≥ 165 мм** соответствует санкционной позиции. Нужна индивидуальная проверка запрета до попытки экспорта; не рассчитывайте на «личное использование» как гарантированное исключение.
3. **Гражданин Германии, номер DE, электрический SUV, 180 мм, цена 28 000 €:** отсутствие ДВС не даёт автоматического исключения: электромобили с просветом **≥ 165 мм** присутствуют в ограниченном перечне.
4. **Гражданин Беларуси, номера BY, возвращается в ЕС:** маршрут через Польшу может предполагать условия собственника и личного использования; через Литву действуют более строгие опубликованные критерии, включая литовские документы; через Латвию обычный частный въезд на BY-номерах официально запрещён. Право человека на въезд оценивается отдельно от права автомобиля.
5. **Гражданка Франции, французские номера, седан CN 8703, клиренс 140 мм и стоимость 68 000 €:** одна лишь цена **не образует автоматический запрет по Приложению XXV** после поправки 2025/2041. Для вывоза всё равно проверяют точный CN, иные санкции и конкретные документы. [S26]

## 8. Методология, пределы исследования и обновления

Материал использует четыре уровня источников: **регламенты ЕС и их приложения → разъяснения таможенных служб Польши/Литвы/Латвии → пограничные службы и МИД → нормы таможенного права ЕАЭС**. Из официального текста выведены только общие правила; **индивидуальная санкционная/таможенная классификация должна проверяться по CN/VIN и документам**. Консолидированный EUR-Lex носит справочный характер: при расхождении юридически значимы официально опубликованные тексты актов и поправок. Среди важных обновлений 2026 г. — Регламенты **2026/513**, **2026/1846** и **2026/1817**; проверяйте новые редакции непосредственно перед поездкой. ЕС продлил белорусский санкционный режим до **28 февраля 2027 года** — это **не означает** неизменность всех частных пограничных правил до этой даты. [S1][S4][S14][S19][S20][S24]

**Отдельный санкционный скрининг:** санкции ЕС включают не только товары, но и ограничения для лиц и организаций. Индивидуальная проверка санкционных списков требуется при потенциально коммерческой сделке, корпоративном автомобиле, оплате и услугах; анкета не проверяет ФИО, VIN, контрагентов и банковские ограничения. [S14][S19]

**Перед выездом:** проверьте (1) пропускной пункт и очередь, (2) визу/безвиз, (3) санкции по CN, типу двигателя, точному объёму, клиренсу и стоимости, (4) правила обратного въезда по номерным знакам, (5) временный ввоз/растаможку и страховку. При спорных характеристиках автомобиля получите **письменный ответ соответствующей таможни** до поездки.

## Первичные и официальные источники
- **[S1]** [Regulation (EC) No 765/2006, consolidated version 24.07.2026](https://eur-lex.europa.eu/eli/reg/2006/765/2026-07-24/eng)
- **[S2]** [Lithuanian Customs: export restrictions on passenger cars, 15.09.2026](https://mano.muitine.lt/en/knowledge-bank/prohibitions-and-restrictions/international-sanctions/restrictions-export-passenger-vehicles-belarus)
- **[S3]** [Council Regulation (EU) 2025/1472, changes to Annex XVIII](https://eur-lex.europa.eu/eli/reg/2025/1472/oj/eng)
- **[S4]** [Council Regulation (EU) 2026/513 (April 2026)](https://eur-lex.europa.eu/eli/reg/2026/513/oj/eng)
- **[S5]** [Polish Customs: Belarus-plated vehicles, 22.07.2024](https://www.gov.pl/web/kas/nowe-zasady-przywozu-samochodow-osobowych-zarejestrowanych-na-bialorusi)
- **[S6]** [Lithuanian Customs: Belarus-plated vehicles, 26.11.2024](https://muitine.lrv.lt/en/news/updated-procedure-for-admitting-cars-with-belarusian-registration-to-enter-lithuania/)
- **[S7]** [Latvian Revenue Service: Belarus-plated cars, 15.07.2024](https://www.vid.gov.lv/lv/jaunums/personas-ar-baltkrievijas-republika-registretu-transportlidzekli-turpmak-nevares-iebraukt-latvija)
- **[S8]** [Polish Customs: Bobrowniki and Kuźnica reopened, 17.11.2025](https://www.gov.pl/web/kas/przejscia-graniczne-z-bialorusia-w-bobrownikach-i-kuznicy-otwarte)
- **[S9]** [Lithuanian Border Guard: Medininkai and Šalčininkai reopened, 19.11.2025](https://vsat.lrv.lt/lt/naujienos/atidaromi-salcininku-ir-medininku-pasienio-kontroles-punktai/)
- **[S10]** [Latvian electronic border reservation system, 2026](https://www.lvborder.lv/en/)
- **[S11]** [Belarus State Border Committee: visa waiver extended to 31.12.2026](https://t.me/s/gpkgovby?before=8073)
- **[S12]** [Bulgarian MFA: visa-free conditions / Belarus, 14.09.2026](https://www.mfa.bg/en/embassyinfo/belarus)
- **[S13]** [EAEU Customs Code, Art. 264: temporary import of personal vehicles](https://eec.eaeunion.org/upload/iblock/93c/TK-EAES.pdf)
- **[S14]** [Council of EU: Belarus sanctions overview, 2026](https://www.consilium.europa.eu/en/policies/sanctions-against-belarus/)
- **[S15]** [Polish Border / Customs official crossing data](https://granica.gov.pl/)
- **[S16]** [Polish MFA: bilateral motor insurance / Green Cards, 08.05.2023](https://www.gov.pl/web/bialorus/komunikat-dla-kierowcow-udajacych-sie-na-bialorus)
- **[S17]** [EU Commission: Schengen visa policy](https://home-affairs.ec.europa.eu/policies/schengen/visa-policy_en)
- **[S18]** [Council of EU: Schengen vs EU and visa states](https://www.consilium.europa.eu/en/policies/eu-visa-policy/)
- **[S19]** [EU Belarus listings: implementing regulation 2026/1817](https://eur-lex.europa.eu/eli/reg_impl/2026/1817/oj/eng)
- **[S20]** [Council Regulation (EU) 2026/1846 (July 2026)](https://eur-lex.europa.eu/eli/reg/2026/1846/oj/eng)
- **[S21]** [Belarus: official border queues and checkpoints](https://gpk.gov.by/)
- **[S22]** [UK FCDO: Belarus entry, 2026](https://www.gov.uk/foreign-travel-advice/belarus/entry-requirements)
- **[S23]** [EAEU Council Decision No.107: customs for personal vehicles (amended text, Garant)](https://base.garant.ru/71903282/)
- **[S24]** [Council of EU: sanctions against Belarus timeline, 2026](https://www.consilium.europa.eu/en/policies/sanctions-against-belarus/timeline-eu-sanctions-against-belarus/)
- **[S25]** [Latvian government: electronic queue mandatory since 15.10.2025](https://www.lvrtc.lv/en/news/jaunumi/no-sodienas-latvijas-robezu-ar-krieviju-un-baltkrieviju-var-skersot-tikai-pec-registracijas-elektroniskas-rindas-rezervacijas-sistema/)
- **[S26]** [Council Regulation (EU) 2025/2041: amended Annex XXV luxury goods vehicle CN list](https://eur-lex.europa.eu/eli/reg/2025/2041/oj/eng)


---

# Driving to Belarus from Poland, Lithuania or Latvia in 2026: passports, vehicle restrictions and border rules

**Comfortline.by regulatory research guide • Verified 16 October 2026 • Edition 1.0**

**Executive summary.** A road trip must pass five separate checks: (1) the traveller's right to enter Belarus and return to the EU, (2) an operating border crossing, (3) EU vehicle export sanctions, (4) any Belarus-plate re-entry restrictions imposed by EU states, and (5) Belarus/EAEU customs rules. Citizenship, residence, vehicle registration, ownership, commercial use, engine specification, ground clearance and value all matter. **An open crossing does not mean a particular vehicle is allowed, nor that a passenger has a right to cross.**

> **Important:** This is a research-based travel guide, not a binding customs ruling or legal opinion. The interactive checker is a preliminary screen and cannot issue permission to cross. Official rules and checkpoint status can change rapidly. Check your government's travel advice and do not send passport numbers or VINs in unsecured enquiries.

## 1. Open routes for passenger cars

| From | Main passenger-car crossings (as most recently confirmed) | Notes |
|---|---|---|
| **Poland** | Terespol–Brest; Bobrowniki–Berestovitsa; Kuźnica–Bruzgi | Bobrowniki takes cars and coaches; Kuźnica takes cars **but not coaches**. Połowce and Sławatycze remain closed, while Kukuryki/Koroszczyn is primarily for freight. [S8][S15] |
| **Lithuania** | Medininkai–Kamenny Log; Šalčininkai–Benyakoni | Both reopened in November 2025. Do not assume Lavoriškės/Kotlovka or Raigardas/Privalka is available. [S9][S21] |
| **Latvia** | Pāternieki–Grigorovshchina | Electronic advance vehicle queue booking is mandatory. This crossing has experienced technical disruptions in 2026, so verify its current status. [S10][S25] |

## 2. EU vehicle sanctions: 1,900 cc, 165 mm, €50,000 and age

The central legal instrument is **Council Regulation (EC) No 765/2006**, as amended and consolidated through July 2026. **Article 1bb / Annex XVIII** regulates export of listed items to Belarus; **Article 1ga / Annex XXV** governs luxury goods, and **Article 1ra** covers relevant EU import restrictions. [S1][S3][S4]

### Vehicle technical screening under Annex XVIII

| Vehicle type (CN 8703) | Engine test | Ground-clearance test | Initial result |
|---|---|---|---|
| Petrol, internal combustion only | **More than 1,900 cm³** | **165 mm or greater** | Meeting both may trigger Article 1bb |
| Diesel only | **More than 1,900 cm³** | **165 mm or greater** | Meeting both may trigger Article 1bb |
| Conventional hybrid (HEV) | No 1,900 cm³ threshold in its listed CN description | **165 mm or greater** | Listed vehicle class |
| Plug-in hybrid (PHEV) | No displacement test in its listed CN description | **165 mm or greater** | Listed vehicle class |
| Battery electric (BEV) | Engine capacity not applicable | **165 mm or greater** | Listed vehicle class |
| Other propulsion / specialist vehicle | Exact CN classification required | Category-dependent | Manual legal assessment |

**Boundary values:** exactly 1,900 cc is *not* “more than 1,900”; exactly 165 mm *does* meet “equal to or above 165 mm.” Ground clearance is defined by the listed legal product description, not necessarily the manufacturer’s marketing number. An **ex** CN entry covers only items meeting its detailed definition. Lithuanian Customs' 15 September 2026 guidance offers the clearest published technical table. [S2]

**Vehicle age.** There is **no blanket “cars older/newer than year X are allowed” rule in this Annex XVIII test**. Year of manufacture is instead highly relevant to **permanent EAEU import duties**, which apply age bands up to three years, above three to five years, and over five years. [S13][S23]

**Does a car price over €50,000 automatically bar export? No.** The luxury-goods Annex XXV retains a **more than €50,000** threshold for *certain listed vehicle-related CN codes*. But **Regulation (EU) 2025/2041 replaced Annex XXV table (9) on 23 October 2025**, listing categories such as **8702** (10+ seat vehicles), **8706** (chassis), **8707** (bodies) and **8708** (vehicle parts), **not ordinary passenger cars under CN 8703 in their own right**. Therefore, a conventional CN 8703 sedan or SUV must **not** be labelled prohibited solely because its value exceeds €50,000. Exact CN classification, Annex XVIII tests and other controls still matter. [S1][S26]

**“But I'm just going to visit family in my EU-registered car.”** Lithuanian Customs expressly explained on 15 September 2026 that driving an EU-registered vehicle out of the EU, even with an intended return, constitutes export for customs-law purposes; an electronic export declaration is not always needed, but this does **not** eliminate sanctions. Do not assume temporary private travel is an automatic exemption. [S2]

## 3. Passports: Belarus visa-free entry for all 27 EU countries

Belarus's temporary land-border visa waiver runs through **31 December 2026** for **38 European countries**, namely **all 27 EU member states** (Austria, Belgium, Bulgaria, Croatia, Cyprus, Czechia, Denmark, Estonia, Finland, France, Germany, Greece, Hungary, Ireland, Italy, Latvia, Lithuania, Luxembourg, Malta, Netherlands, Poland, Portugal, Romania, Slovakia, Slovenia, Spain and Sweden) plus **11 non-EU states** (Andorra, Bosnia and Herzegovina, Iceland, Liechtenstein, Monaco, North Macedonia, Norway, San Marino, Switzerland, United Kingdom and Vatican City). There are special provisions for Latvian non-citizens and stateless permanent residents of Estonia; their documentary entitlement must be verified. [S11][S12]

**Polish, Lithuanian and Latvian citizens and Latvian non-citizens:** up to **90 days per visit** and generally no more than **90 days in a calendar year**. **The other 35 nationalities:** up to **30 days per visit**, subject to **90 days per calendar year**. Belarusian citizens use their own national right of entry; for other world nationalities the visa regime must be checked individually. EU/Schengen residence cards alone do not necessarily confer Belarus visa-free admission. The European visa-free land arrangement is not a blanket authorization for travel through Russia, and exclusions apply for certain passport categories. [S11][S22]

**The way back is separate.** Belarusian citizenship or a Belarus visa does not grant admission to Poland, Lithuania or Latvia. EU citizens and third-country nationals follow different rules. A Belarusian/other third-country passport holder needs an applicable EU/Schengen entry basis, plus any additional national border requirements. Short Schengen visits usually observe the **90 days in 180 days** framework. Ireland and Cyprus are EU members but do not issue standard Schengen visas. [S17][S18]

## 4. PL/LT/LV plates vs Belarusian (BY) plates

**EU plates** (PL, LT, LV, DE, etc.): leaving the EU for Belarus requires a sanctions export check regardless of an ordinary tourist purpose. Check registration papers, ownership, insurance and customs status on arrival. [S2]

**BY plates:** The main problem is often the return leg into the EU. **Article 1ra**, along with national implementation, makes outcomes country-dependent:

- **Poland:** the Ministry of Finance/KAS describes conditional admission of qualifying privately owned, non-commercial Belarus-registered cars, notably where the **owner is physically in the car**. This is not blanket permission for corporate/commercial vehicles. [S5]
- **Lithuania:** published exceptions are narrower. They include specified vehicles driven by their Belarusian-citizen owners **holding a valid Lithuanian-issued visa or Lithuanian residence permit**, for strictly private use, as well as certain EU citizens resident in Belarus. A visa issued by a different Schengen state should not be presumed enough for this exception. [S6]
- **Latvia:** the State Revenue Service has announced a general bar on ordinary Belarus-plated private cars entering through Latvian crossings, subject to narrow exceptions such as diplomatic vehicles. **Do not plan to return via Pāternieki in a BY-plated private car without confirmation of an applicable exception.** [S7]

**Other registrations** (GB, CH, NO, US, UA and others) must be considered individually. Registration, customs status and nationality are distinct factors; a non-EU registration does not necessarily mean no EU export controls apply.

## 5. Belarusian customs: a visit is not a permanent import

Under **Article 264 of the EAEU Customs Code**, a foreign individual may temporarily import a personally used, non-EAEU-registered car for up to **one year**, subject to conditions. EAEU-resident individuals generally face **customs-duty security/deposit** requirements for the temporary import of a foreign-registered vehicle, and additional vehicles have separate security provisions. Citizenship is not an adequate proxy for customs residency. [S13]

Permanent vehicle import, resale or local registration is a different regime with **age/engine/value duty bands, relevant taxes, recycling fees and specific powertrain measures**. Do not treat a travel admission as a duty-free permanent import. [S23]

## 6. Documents and insurance

Bring a valid travel document, visa/visa waiver basis as applicable, a driving licence, registration certificate, owner authorization or leasing/rental documents, documents supporting engine displacement and ground clearance, vehicle valuation where needed, and evidence of private travel purpose. Check both Belarusian and EU third-party liability insurance; the traditional reciprocal acceptance of EU/Belarus Green Cards changed in 2023 and **border insurance may be required**. [S16]

Advance registration through **lvborder.lv** is required for vehicle departure via Latvia's eastern border. Confirm all other live checkpoint and queue requirements shortly before departure. [S10][S21]

## 7. Illustrative cases — not crossing permissions

1. **Lithuanian passport; LT plates; petrol 1,798 cc; 150 mm clearance; €14,000; private visit:** the stated Annex XVIII petrol thresholds do not match, but a full sanctions and customs review still applies. Lithuanian citizens benefit from the Belarus visa waiver for up to 90 days per visit.
2. **Polish passport; PL plates; diesel 1,968 cc; 180 mm; model year 2015:** the old model year does not defeat the combined **>1,900 cc and ≥165 mm** restriction; an export prohibition risk must be resolved before driving out of the EU.
3. **German passport; DE plates; 180 mm ground-clearance electric SUV; €28,000:** battery electric does not exempt the car; Annex XVIII includes certain EVs meeting the clearance threshold.
4. **Belarusian passport; BY plates; planned return to the EU:** Polish conditional-owner rules, narrower Lithuanian exceptions and Latvia's general entry bar give materially different return-route outcomes; the driver's Schengen admission is a separate test.
5. **French passport; FR plates; CN 8703 sedan, 140 mm clearance, €68,000:** price alone does **not automatically trigger Annex XXV**, as its table (9) was amended in 2025. The exact CN code and any other applicable prohibitions still require checking. [S26]

## 8. Research method, legal caveats and update policy

The source hierarchy is **EU law (regulations and annexes) → customs agency guidance → border/police/MFA announcements → EAEU customs law**. A detailed finding depends on the precise CN code, official vehicle documentation, beneficial owner, destination/use and applicable derogations. Consolidated EUR-Lex texts are documentation tools; authentic acts and amendments in the Official Journal govern. 2026 developments include Regulations **2026/513, 2026/1846 and 2026/1817**. EU sanctions against Belarus have been extended to **28 February 2027**; this does not guarantee the same rules will persist unchanged until then. [S1][S4][S14][S19][S20][S24]

**Sanctioned-person screening:** EU sanctions also designate persons and companies; corporate transport, payments, vehicle sale or organised transfers require separate counterparty and sanctions-list checks. This form does not screen names, VINs or banks. [S14][S19]

**Before every journey:** verify the checkpoint; passenger documents; CN/powertrain/displacement/clearance/value; return to the EU (especially BY plates); EAEU customs declarations/deposit; insurance and queue booking. For an uncertain vehicle seek **written guidance from the competent national customs office**.

## Official legal and administrative references
- **[S1]** [Regulation (EC) No 765/2006, consolidated version 24.07.2026](https://eur-lex.europa.eu/eli/reg/2006/765/2026-07-24/eng)
- **[S2]** [Lithuanian Customs: export restrictions on passenger cars, 15.09.2026](https://mano.muitine.lt/en/knowledge-bank/prohibitions-and-restrictions/international-sanctions/restrictions-export-passenger-vehicles-belarus)
- **[S3]** [Council Regulation (EU) 2025/1472, changes to Annex XVIII](https://eur-lex.europa.eu/eli/reg/2025/1472/oj/eng)
- **[S4]** [Council Regulation (EU) 2026/513 (April 2026)](https://eur-lex.europa.eu/eli/reg/2026/513/oj/eng)
- **[S5]** [Polish Customs: Belarus-plated vehicles, 22.07.2024](https://www.gov.pl/web/kas/nowe-zasady-przywozu-samochodow-osobowych-zarejestrowanych-na-bialorusi)
- **[S6]** [Lithuanian Customs: Belarus-plated vehicles, 26.11.2024](https://muitine.lrv.lt/en/news/updated-procedure-for-admitting-cars-with-belarusian-registration-to-enter-lithuania/)
- **[S7]** [Latvian Revenue Service: Belarus-plated cars, 15.07.2024](https://www.vid.gov.lv/lv/jaunums/personas-ar-baltkrievijas-republika-registretu-transportlidzekli-turpmak-nevares-iebraukt-latvija)
- **[S8]** [Polish Customs: Bobrowniki and Kuźnica reopened, 17.11.2025](https://www.gov.pl/web/kas/przejscia-graniczne-z-bialorusia-w-bobrownikach-i-kuznicy-otwarte)
- **[S9]** [Lithuanian Border Guard: Medininkai and Šalčininkai reopened, 19.11.2025](https://vsat.lrv.lt/lt/naujienos/atidaromi-salcininku-ir-medininku-pasienio-kontroles-punktai/)
- **[S10]** [Latvian electronic border reservation system, 2026](https://www.lvborder.lv/en/)
- **[S11]** [Belarus State Border Committee: visa waiver extended to 31.12.2026](https://t.me/s/gpkgovby?before=8073)
- **[S12]** [Bulgarian MFA: visa-free conditions / Belarus, 14.09.2026](https://www.mfa.bg/en/embassyinfo/belarus)
- **[S13]** [EAEU Customs Code, Art. 264: temporary import of personal vehicles](https://eec.eaeunion.org/upload/iblock/93c/TK-EAES.pdf)
- **[S14]** [Council of EU: Belarus sanctions overview, 2026](https://www.consilium.europa.eu/en/policies/sanctions-against-belarus/)
- **[S15]** [Polish Border / Customs official crossing data](https://granica.gov.pl/)
- **[S16]** [Polish MFA: bilateral motor insurance / Green Cards, 08.05.2023](https://www.gov.pl/web/bialorus/komunikat-dla-kierowcow-udajacych-sie-na-bialorus)
- **[S17]** [EU Commission: Schengen visa policy](https://home-affairs.ec.europa.eu/policies/schengen/visa-policy_en)
- **[S18]** [Council of EU: Schengen vs EU and visa states](https://www.consilium.europa.eu/en/policies/eu-visa-policy/)
- **[S19]** [EU Belarus listings: implementing regulation 2026/1817](https://eur-lex.europa.eu/eli/reg_impl/2026/1817/oj/eng)
- **[S20]** [Council Regulation (EU) 2026/1846 (July 2026)](https://eur-lex.europa.eu/eli/reg/2026/1846/oj/eng)
- **[S21]** [Belarus: official border queues and checkpoints](https://gpk.gov.by/)
- **[S22]** [UK FCDO: Belarus entry, 2026](https://www.gov.uk/foreign-travel-advice/belarus/entry-requirements)
- **[S23]** [EAEU Council Decision No.107: customs for personal vehicles (amended text, Garant)](https://base.garant.ru/71903282/)
- **[S24]** [Council of EU: sanctions against Belarus timeline, 2026](https://www.consilium.europa.eu/en/policies/sanctions-against-belarus/timeline-eu-sanctions-against-belarus/)
- **[S25]** [Latvian government: electronic queue mandatory since 15.10.2025](https://www.lvrtc.lv/en/news/jaunumi/no-sodienas-latvijas-robezu-ar-krieviju-un-baltkrieviju-var-skersot-tikai-pec-registracijas-elektroniskas-rindas-rezervacijas-sistema/)
- **[S26]** [Council Regulation (EU) 2025/2041: amended Annex XXV luxury goods vehicle CN list](https://eur-lex.europa.eu/eli/reg/2025/2041/oj/eng)
